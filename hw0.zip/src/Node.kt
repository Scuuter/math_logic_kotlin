class Node(val operation: Operation, val leftChild: Node?, val rightChild: Node?) {
    override fun toString(): String {
        if (operation.isVariable()) {
            return operation.toString();
        }
        if (operation.isUnary()) {
            return "(" + operation.toString() + leftChild.toString() + ")";
        }
        return "(" + operation.toString() + "," + leftChild.toString() + "," + rightChild.toString() + ")"
    }
}