class Parser() {
    private var expression: String
    private var pos: Int
    var tree: Node?

    init {
        this.expression = ""
        this.pos = 0
        this.tree = null
    }

    fun parse(expression: String): Node? {
        this.expression = expression.replace("\\p{javaWhitespace}".toRegex(), "") + "\u0000"
        this.pos = 0
        this.tree = parseImpl()
        return tree
    }

    private fun parseImpl(): Node? {
        val left = parseDisj()
        var root: Node? = null

        if (isOp("->")) {
            root = Node(Operation(Operation.Type.IMPLICATION, null), left, parseImpl())
        }

        if (root != null) {
            return root
        }
        else {
            return left
        }
    }

    private fun parseDisj(): Node? {
        var left = parseConj()
        var root: Node? = null

        while (isOp("|")) {
            root = Node(Operation(Operation.Type.DISJUNCTION, null), left, parseConj())
            left = root
        }

        if (root != null) {
            return root
        }
        else {
            return left
        }
    }

    private fun parseConj(): Node? {
        var left = parseNeg()
        var root: Node? = null

        while (isOp("&")) {
            root = Node(Operation(Operation.Type.CONJUNCTION, null), left, parseNeg())
            left = root
        }

        if (root != null) {
            return root
        }
        else {
            return left
        }
    }

    private fun parseNeg(): Node? {
        if (isOp("!")) {
            return Node(Operation(Operation.Type.NEGATION, null), parseNeg(), null)
        }

        if (isOp("(")) {
            val result = parseImpl()
            pos++
            return result
        }

        return parseVar()
    }

    private fun parseVar(): Node {
        var endIndex = pos

        while (Character.isLetter(expression[endIndex]) || Character.isDigit(expression[endIndex])) {
            endIndex++
        }

        val `var` = expression.substring(pos, endIndex)
        pos = endIndex
        return Node(Operation(Operation.Type.VARIABLE, `var`), null, null)
    }

    private fun isOp(op: String): Boolean {
        if (expression.startsWith(op, pos)) {
            pos += op.length
            return true
        }
        return false
    }

    fun treeToString(): String {
        return tree.toString()
    }
}