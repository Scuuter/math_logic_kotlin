class Operation(val type: Type, val value: String?) {
    enum class Type(val code: Int, val symbol: String?) {
        VARIABLE(0, null),
        NEGATION(1, "!"),
        CONJUNCTION(2, "&"),
        DISJUNCTION(3, "|"),
        IMPLICATION(4, "->")
    }

    fun isVariable(): Boolean {
        return type == Type.VARIABLE;
    }

    fun isUnary(): Boolean {
        return type == Type.NEGATION;
    }

    fun isBinary(): Boolean {
        return type.code >= 2
    }

    override fun toString(): String {
        if (isVariable()) {
            /*
            if (value!!.length > 1)
                return "(" + value + ")"
                */
            return value!!;
        }
        return type.symbol!!;
    }
}