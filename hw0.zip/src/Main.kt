
import java.nio.file.Paths
import java.nio.file.Files


fun main(args: Array<String>) {
    val parser = Parser()
    Files.newBufferedReader(Paths.get("input.txt")).use { reader ->
        Files.newBufferedWriter(Paths.get("output.txt")).use { writer ->
            parser.parse(reader.readLine())
            writer.write(parser.treeToString())
        }
    }
}